def display_chat_ui(messages):
    print("=== N Chat ===\n")
    for msg in messages:
        sender = "🟢 You" if msg["from_me"] else "🔴 Friend"
        print(f"{sender}: {msg['text']}")