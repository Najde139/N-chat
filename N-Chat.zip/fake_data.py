def get_fake_messages():
    return [
        {"from_me": True, "text": "مرحباً! كيف حالك؟"},
        {"from_me": False, "text": "أهلاً! أنا بخير، ماذا عنك؟"},
        {"from_me": True, "text": "أنا متحمس للعمل على N Chat 🎉"},
        {"from_me": False, "text": "فكرة رائعة! لنبدأ الآن."}
    ]