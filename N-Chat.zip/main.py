from chat_ui import display_chat_ui
from fake_data import get_fake_messages

if __name__ == "__main__":
    messages = get_fake_messages()
    display_chat_ui(messages)